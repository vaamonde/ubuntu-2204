/* Automatically generated from om_tcp-api.xml by codegen.pl */
#ifndef __NX_EXPR_FUNCPROC_om_tcp_H
#define __NX_EXPR_FUNCPROC_om_tcp_H

#include "../../../common/expr.h"
#include "../../../common/module.h"

#define nx_api_declarations_om_tcp_func_num 0

/* PROCEDURES */

#define nx_api_declarations_om_tcp_proc_num 1
void nx_expr_proc__om_tcp_reconnect(nx_expr_eval_ctx_t *eval_ctx, nx_module_t *module, nx_expr_list_t *args);


#endif /* __NX_EXPR_FUNCPROC_om_tcp_H */
