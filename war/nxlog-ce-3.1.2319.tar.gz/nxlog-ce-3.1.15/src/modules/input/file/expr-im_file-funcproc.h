/* Automatically generated from im_file-api.xml by codegen.pl */
#ifndef __NX_EXPR_FUNCPROC_im_file_H
#define __NX_EXPR_FUNCPROC_im_file_H

#include "../../../common/expr.h"
#include "../../../common/module.h"


/* FUNCTIONS */

#define nx_api_declarations_im_file_func_num 1
void nx_expr_func__im_file_file_name(nx_expr_eval_ctx_t *eval_ctx, nx_module_t *module, nx_value_t *retval, int32_t num_arg, nx_value_t *args);
#define nx_api_declarations_im_file_proc_num 0


#endif /* __NX_EXPR_FUNCPROC_im_file_H */
