#!/usr/bin/perl

use strict;
use warnings;
use Config;

print "$Config{installvendorlib}";
